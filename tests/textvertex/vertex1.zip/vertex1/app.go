package main

import (
	"github.com/hamzam15comp/vertex"
	"log"
	"os"
	"time"
	"strconv"
)

var logger *log.Logger

func logInit() {
	f, err := os.OpenFile("apperrors.log",
		os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Println(err)
	}

	logger = log.New(f, "", log.Lmicroseconds | log.LUTC)
}

func main() {
	logInit()
	err := vertex.LaunchApp()
	if err != nil {
		logger.Println("Error: ", err)
	}
	logger.Println("Created IN and OUT pipe")
	i := 1
	time.Sleep(80 * time.Second)
	for {
		datatype := "m:" + strconv.Itoa(i)
		data := []byte("Vertex1 says Hello!\n")
		time.Sleep(1 * time.Second)
		logger.Println(
			"$S$",
			len(string(data)+datatype),
			"$",
			datatype,
		)
		err = vertex.WriteData("all", datatype, data)
		if err != nil {
			logger.Println(err)
		}
		i = i + 1
	}
}
